package alap01;

public class BekeresEllenorzesGyakorlas {

    public static void main(String[] args) {
        String valasz = bekeres("kérdés");
        boolean csakSzam = csakSzamjegy(valasz);
    }

    private static String bekeres(String kerdes) {
        String valasz = "";
        /* JOP */
        
        return valasz;
    }

    private static boolean csakSzamjegy(String adat) {
        boolean csakSzam = false;
        /* Character.isDigit(adat karaktere) */
        
        return csakSzam;
    }   
}

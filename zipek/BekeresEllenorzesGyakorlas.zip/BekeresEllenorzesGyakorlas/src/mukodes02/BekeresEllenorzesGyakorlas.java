package mukodes02;

import javax.swing.JOptionPane;


public class BekeresEllenorzesGyakorlas {

    public static void main(String[] args) {
        String valasz = bekeres("kérek 1 egész számot:");
        boolean csakSzam = csakSzamjegy(valasz);
        if(csakSzam){
            int szam = Integer.parseInt(valasz);
            primVizsgalatKiirasa(szam);
        }
    }

    private static String bekeres(String kerdes) {
        String valasz = "";
        valasz = JOptionPane.showInputDialog(kerdes);
        return valasz;
    }

    private static boolean csakSzamjegy(String adat) {
        int N = adat.length();
        int i = 0;
        while( i < N && Character.isDigit( adat.charAt(i) ) ){
            i++;
        }
        
        boolean csakSzam = i >= N;
        return csakSzam;
    }

    private static void primVizsgalatKiirasa(int szam) {
        boolean primE = false;
        
        String info = "a(z) " + szam + " ";
        info += primE ? "prím" : "nem prím";
        JOptionPane.showMessageDialog(null, info);
    }
}

package megoldas04;

import javax.swing.JOptionPane;


public class BekeresEllenorzesGyakorlas {

    public static void main(String[] args) {
        String valasz = bekeres("kérek 1 egész számot:");
        boolean csakSzam = csakSzamjegy(valasz);
        if(csakSzam){
            int szam = Integer.parseInt(valasz);
            primVizsgalatKiirasa(szam);
            tokeletesVizsgalatKiiras(szam);
        }else{
            //JOptionPane.showMessageDialog(null, "Ez nem szám!");
            betuDbKiirasa('e', valasz);
        }
    }

    private static String bekeres(String kerdes) {
        String valasz = "";
        valasz = JOptionPane.showInputDialog(kerdes);
        return valasz;
    }

    private static boolean csakSzamjegy(String adat) {
        int N = adat.length();
        int i = 0;
        while( i < N && Character.isDigit( adat.charAt(i) ) ){
            i++;
        }
        
        boolean csakSzam = i >= N;
        return csakSzam;
    }

    private static void primVizsgalatKiirasa(int szam) {
        boolean primE;
        if (szam < 2) {
            primE = false;
        } else {
            int i = 2;
            while (i <= Math.sqrt(szam) && !(szam % i == 0)) {
                i++;
            }
            primE = i > Math.sqrt(szam);
        }
        
        String info = "a(z) " + szam + " ";
        info += primE ? "prím" : "nem prím";
        JOptionPane.showMessageDialog(null, info);
    }    

    private static void tokeletesVizsgalatKiiras(int szam) {
        int osztokOsszege = 0;
        for (int i = 1; i <= szam / 2; i++) {
            if(szam % i == 0){
                osztokOsszege += i;
            }
        }
        boolean tokeletesE = osztokOsszege == szam;
        
        String info = "a(z) " + szam + " ";
        info += tokeletesE ? "tökéletes" : "nem tökéletes";
        JOptionPane.showMessageDialog(null, info);
    }

    private static void betuDbKiirasa(char betu, String adat) {
       int betuDb = 0;
        for (int i = 0; i < adat.length(); i++) {
            if(adat.charAt(i) == betu){
                betuDb++;
            }
        }
        
        String info = String.format("a(z) \"%s\" adatban a(z) %c száma: %d\n",adat,betu, betuDb );
        JOptionPane.showMessageDialog(null, info);
    }
}

package szamlaprojektek;

public class SzamlaProjektek {

    public static void main(String[] args) {
        System.out.println("********************");
        System.out.println("     Nyugta 1");
        System.out.println("********************");
        System.out.println("Tétel 1:      350 Ft");
        System.out.println("Tétel 1:       90 Ft");
        System.out.println("Tétel 1:     1320 Ft");
        System.out.println("====================");
        System.out.println("Összesen:    1760 Ft");
        System.out.println("_______      _______");
        System.out.println(" Dátum         Név");
        System.out.println("********************");
        System.out.println("         CÉG");
        System.out.println("********************");
    }
    
}


import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class PappNikoletta_Kviz {

    public static void main(String[] args) {
        int ujra = 1;
        while (ujra == 1) {
            int helyesvalaszok = 0;
            String nev = JOptionPane.showInputDialog("Adja meg a nevét! Számokat nem tartalmazhat!!");
            String cim = "Programozás kvíz";
            boolean jo = nev.length() >= 3;
            String kerdes;
            int valaszkozles;
            valaszkozles = JOptionPane.INFORMATION_MESSAGE;
            int info = JOptionPane.OK_OPTION;
            while (!jo) {
                nev = JOptionPane.showInputDialog("Adja meg a nevét! Legyen hosszabb mint 3 karakter!!!!");
                if (nev.length() >= 3) {
                    jo = true;
                }
            }
            int szohossz = nev.length();

            for (int i = 0; i < szohossz; i++) {
                boolean vanBenneSzam = nev.charAt(i) == '0' || nev.charAt(i) == '1' || nev.charAt(i) == '2'
                        || nev.charAt(i) == '3' || nev.charAt(i) == '4' || nev.charAt(i) == '5'
                        || nev.charAt(i) == '6' || nev.charAt(i) == '7' || nev.charAt(i) == '8'
                        || nev.charAt(i) == '9';
                while (vanBenneSzam) {
                    nev = JOptionPane.showInputDialog("Adja meg a nevét! Nincs szám: ");
                    vanBenneSzam = nev.charAt(i) == '0' || nev.charAt(i) == '1' || nev.charAt(i) == '2'
                            || nev.charAt(i) == '3' || nev.charAt(i) == '4' || nev.charAt(i) == '5'
                            || nev.charAt(i) == '6' || nev.charAt(i) == '7' || nev.charAt(i) == '8'
                            || nev.charAt(i) == '9';
                }

            }

            JOptionPane.showConfirmDialog(null, nev, cim, info, valaszkozles);
            info = JOptionPane.YES_NO_OPTION;
            kerdes = "Szeretné elkezdeni a tesztet?";
            valaszkozles = JOptionPane.QUESTION_MESSAGE;
            int valasz1 = JOptionPane.showConfirmDialog(null, kerdes, cim, info);

            cim = "Programozás kvíz";
            int Kviznev = JOptionPane.QUESTION_MESSAGE;
            Icon kep = new ImageIcon("src/kepek/foto.png");
            Object[] valaszok = {"semmi", "Az egyik szám a másik szöveg", "Az előbbi karakterlánc, az utóbbi egy karakter",
                "az egyik egész szám a másik lebegő pontos"};
            Object kijelolve = "....";
            kerdes = "Mi a külnbség a string és a char között ";
            Object valasztas = JOptionPane.showInputDialog(null, kerdes, cim, valaszkozles, kep, valaszok, kijelolve);
            if (valasztas == "Az előbbi karakterlánc, az utóbbi egy karakter") {
                helyesvalaszok++;
            }
            kerdes = "Mi a while ciklus?";
            Object[] valasz2 = {"számláló ciklus", "Elől tesztelő ciklus", "Hátul tesztelő ciklus", "ha ciklus"};
            Object valasztas2 = JOptionPane.showInputDialog(null, kerdes, cim, valaszkozles, kep, valasz2, kijelolve);
            if (valasztas2 == "Elől tesztelő ciklus") {
                helyesvalaszok++;
            }
            kerdes = "Ehhez melyik programozási tétel kell: "
                    + "Számold ki az osztály átlagát";
            Object[] valasz3 = {"megszámlálás", "összegzés", "kiválasztás", "Szélsőérték"};
            Object valasztas3 = JOptionPane.showInputDialog(null, kerdes, cim, valaszkozles, kep, valasz3, kijelolve);
            if (valasztas3 == "összegzés") {
                helyesvalaszok++;
            }

            kerdes = "Mennyi az értéke: Math.abs(-4.7)?";

            String valasztas4 = JOptionPane.showInputDialog(null, kerdes, cim, valaszkozles);
            int helyes = Integer.parseInt(valasztas4);
            if (helyes == 4.7) {
                helyesvalaszok++;
            }
            kerdes = "Milyen nyelv a java?";
            Object[] valasz5 = {"verzió követő nyelv", "nyílt forráskódú", "OOP"};
            Object valasztas5 = JOptionPane.showInputDialog(null, kerdes, cim, valaszkozles, kep, valasz5, kijelolve);
            if (valasztas5 == "OOP") {
                helyesvalaszok++;
            }
            String vege = "Gratulálok! A pontszámod: " + helyesvalaszok + "\n Szeretné újra kezdeni?";
            info = JOptionPane.YES_NO_OPTION;
            valaszkozles = JOptionPane.YES_NO_OPTION;
            int valaszokvege = JOptionPane.showConfirmDialog(null, vege, cim, info, valaszkozles);
            if (valaszokvege == JOptionPane.YES_OPTION) {
                ujra = 1;
            } else {
                ujra = 0;
            }
        }
    }
}

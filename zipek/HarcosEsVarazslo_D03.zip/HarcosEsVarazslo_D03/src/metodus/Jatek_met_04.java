package metodus;

public class Jatek_met_04 {
    
    static int hElet, vElet, korDb;
    static final String TAB = "   ";
        
    public static void main(String[] args) { 
        jatekok();
    }

    private static void jatekok() {
        jatek3Korig();
        jatekHalalig();
    }

    private static void jatek3Korig() {
        kezdes("3 körös játék");
        for (int i  = 0; i < 3; i++) {
            ujKor();
        }
    }
    
    private static void jatekHalalig() {
        kezdes("\n----------\nHalálig tartó játék");
        while (hElet > 0 && vElet > 0) {
            ujKor();
        }
    }

    private static void kezdes(String jatekTipus) {
        korDb = 0;
        hElet = 9;
        vElet = 9;
        System.out.println(jatekTipus);
        System.out.println("KEZDÉS:");
        kiiras();
    }

    private static void ujKor() {
        System.out.println(++korDb + ". kör");
        int hHely = (int)(Math.random()*3);
        int vHely = (int)(Math.random()*3);
        if(hHely == vHely){
            harc();
        }else{
            kalandozas();
        }
        kiiras();
    }

    private static void kiiras() {
        System.out.printf("%sH:%d V:%d\n", TAB, hElet, vElet);
    }

    private static void harc() {
        System.out.println(TAB + "HARC:");
        int dobas = (int)(Math.random()*6)+1;
        hElet -= dobas;
        dobas = (int)(Math.random()*6)+1;
        vElet -= dobas;
    }

    private static void kalandozas() {
        System.out.println(TAB + "KALANDOZÁS:");
    }
    
}

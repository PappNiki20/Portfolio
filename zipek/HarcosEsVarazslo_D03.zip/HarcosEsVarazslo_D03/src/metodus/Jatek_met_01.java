package metodus;

public class Jatek_met_01 {
    
    static int hElet, vElet;
        
    public static void main(String[] args) {
        String tab = "   ";
        
        System.out.println("3 körös játék");
        
        kezdes(tab);
        
        for (int i = 0; i < 3; i++) {
            ujKor_V1(i, tab);
        }

        System.out.println("\n----------\nHalálig tartó játék");
        kezdes(tab);
        int korDb = 0;
        while (hElet > 0 && vElet > 0) {
            ujKor_V2(korDb, tab);
            korDb++;
        }
    }

    private static void ujKor_V2(int korDb, String tab) {
        //kor++;
        System.out.println(++korDb + ". kör");
        int hHely = (int)(Math.random()*3);
        int vHely = (int)(Math.random()*3);
        if(hHely == vHely){
            System.out.println(tab + "HARC:");
            int dobas = (int)(Math.random()*6)+1;
            hElet -= dobas;
            dobas = (int)(Math.random()*6)+1;
            vElet -= dobas;
        }else{
            System.out.println(tab + "KALANDOZÁS:");
        }
        System.out.printf("%sH:%d V:%d\n", tab, hElet, vElet);
    }

    private static void ujKor_V1(int i, String tab) {
        System.out.println((i+1) + ". kör");
        int hHely = (int)(Math.random()*3);
        int vHely = (int)(Math.random()*3);
        if(hHely == vHely){
            System.out.println(tab + "HARC:");
            int dobas = (int)(Math.random()*6)+1;
            hElet -= dobas;
            dobas = (int)(Math.random()*6)+1;
            vElet -= dobas;
        }else{
            System.out.println(tab + "KALANDOZÁS:");
        }
        System.out.printf("%sH:%d V:%d\n", tab, hElet, vElet);
    }

    private static void kezdes(String tab) {
        hElet = 9;
        vElet = 9;
        System.out.println("KEZDÉS:");
        System.out.printf("%sH:%d V:%d\n", tab, hElet, vElet);
    }
    
}
